"""init module for NetskopeToAzureStorage activity function."""

import json
from .netskope_to_azure_storage import NetskopeToAzureStorage


async def main(typesubtypedata: str) -> str:
    """Initialize netskope_to_azure_storage object and start execution."""
    json_decoded_data = json.loads(typesubtypedata)
    netskope_to_azure_storage = NetskopeToAzureStorage(
        json_decoded_data.get("type_of_data"), json_decoded_data.get("sub_type")
    )
    await netskope_to_azure_storage.initiate_and_manage_iterators()
