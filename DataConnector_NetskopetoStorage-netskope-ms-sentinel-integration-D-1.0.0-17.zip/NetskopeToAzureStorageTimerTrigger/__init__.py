"""Start the function invocations at the given timer."""
import logging
import azure.functions as func
from azure.durable_functions import DurableOrchestrationClient


async def main(mytimer: func.TimerRequest, starter: str) -> None:
    """Start the durable orchaestration."""
    client = DurableOrchestrationClient(starter)
    instance_id = await client.start_new("NetskopeToAzureStorageOrchaestrator", None, None)

    logging.info(f"Started orchestration with ID = '{instance_id}'.")

    if mytimer.past_due:
        logging.info('The timer is past due!')
