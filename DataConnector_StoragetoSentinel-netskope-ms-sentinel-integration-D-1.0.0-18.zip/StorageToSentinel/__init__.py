"""Init for Netskope Azure storage to Sentinel."""

# This function is not intended to be invoked directly. Instead it will be
# triggered by an orchestrator function.
# Before running this sample, please:
# - create a Durable orchestration function
# - create a Durable HTTP starter function
# - add azure-functions-durable to requirements.txt
# - run pip install -r requirements.txt

from .netskope_azure_storage_to_sentinel import NetskopeAzureStorageToSentinel


async def main(sharename: str) -> str:
    """Driver method for azure storage to sentinel."""
    state_manager_to_sentinel_obj = NetskopeAzureStorageToSentinel(sharename)
    await state_manager_to_sentinel_obj.driver_code()
